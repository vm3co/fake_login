import React, { useEffect, useState } from "react";

const ShowLog = () => {
  const [logData, setLogData] = useState([]);

  useEffect(() => {
    fetch("/api/showlog")
      .then((res) => res.json())
      .then((json) => {
        if (json.status === "success") {
          setLogData(json.data);
        }
      });
  }, []);

  return (
    <div>
      <h4 className="mb-3">訪客紀錄清單</h4>
      <div className="table-responsive">
        <table className="table table-bordered table-striped">
          <thead className="table-light">
            <tr>
              <th>時間</th>
              <th>動作</th>
              <th>網址</th>
              <th>IP</th>
              <th>Email</th>
            </tr>
          </thead>
          <tbody>
            {logData.map((row, index) => (
              <tr key={index}>
                <td>{row.timestamp}</td>
                <td>{row.action}</td>
                <td>{row.url}</td>
                <td>{row.ip}</td>
                <td>{row.email}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ShowLog;
